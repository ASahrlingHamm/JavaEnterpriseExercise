package com.asahrlinghamm.individuelluppgiftjavaee;

import com.asahrlinghamm.individuelluppgiftjavaee.Entities.Member;
import com.asahrlinghamm.individuelluppgiftjavaee.Services.MemberService;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class IndividuellUppgiftJavaEeApplication {

    public static void main(String[] args) {
        SpringApplication.run(IndividuellUppgiftJavaEeApplication.class, args);
    }

}
