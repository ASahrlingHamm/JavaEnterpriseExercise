package com.asahrlinghamm.individuelluppgiftjavaee;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class IndividuellUppgiftJavaEeApplicationTests {

    @Test
    void contextLoads() {
    }

}
